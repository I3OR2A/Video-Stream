package com.zj.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zj.entity.Camera;

public interface CameraMapper extends BaseMapper<Camera>{

//	@Select("select id from camera")
//	List<Camera> listCamera();
}
